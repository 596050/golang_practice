/*
Copyright © 2020 The Pragmatic Programmers, LLC
Copyrights apply to this source code.
Check LICENSE for details.

*/
package main

import "pragprog.com/rggo/apis/todoClient/cmd"

func main() {
  cmd.Execute()
}
