// +build containers disable_notification

package app

func send_notification(msg string) {
  return
}
