package add

func add(a, b int) int {
  return a + b
}
